package trabalho;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import java.awt.CardLayout;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JComboBox;
import javax.swing.SwingConstants;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.awt.Window.Type;
import java.awt.Dialog.ModalExclusionType;
import java.awt.Color;
import java.awt.Font;




public class MainFrame {

	private JFrame frmDevoluoDeLivro;
	private JTextField textFieldNomeLivro;
	private JTextField textFieldAutor;
	private JTextField TextField_Editoralivro;
	private JPanel panelCadastrarLivro;
	private JTextField textFieldNameCadUser;
	private JTextField textFieldFoneCadUser;
	private JTextField textCPFCadUser;
	private JTextField textField_DataRetirada;
	private JTextField textField_DataDevolucao;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MainFrame window = new MainFrame();
					window.frmDevoluoDeLivro.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public MainFrame() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame. # INICIALIZA�AO DO MAIN FRAME
	 *
	 */
	private void initialize() {
		frmDevoluoDeLivro = new JFrame();
		frmDevoluoDeLivro.setType(Type.UTILITY);
		frmDevoluoDeLivro.setTitle("IFRS-FELIZ BIBLIOTECA");
		frmDevoluoDeLivro.setBounds(100, 100, 450, 300);
		frmDevoluoDeLivro.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmDevoluoDeLivro.getContentPane().setLayout(new CardLayout(0, 0));
		
		JPanel mainFrame = new JPanel();
		frmDevoluoDeLivro.getContentPane().add(mainFrame, "name_42072309762100");
		mainFrame.setLayout(null);
		
		//INICIALIZA��O DO ARRAY DE LIVROS QUANDO INICIA O CODIGO
		
		File NomesLivros = new File("dados/NomesLivrosCadastrados.txt");
		File CadastroLivros = new File("dados/CadastroLivros.txt");
		File CadastroUsuarios = new File("dados/CadastroUsuarios.txt");
		File NomesUsuarios = new File("dados/NomesUsuarios.txt");
		File EmprestimoLivros = new File("dados/Emprestimos.txt");
		
		
		

//###########################################################################################
// PARTE DO CODIGO QUE TRATA SOBRE RETIRADA DE LIVROS:
		
		JPanel panelRetirarLivro = new JPanel();
		frmDevoluoDeLivro.getContentPane().add(panelRetirarLivro, "name_42072323130900");
		panelRetirarLivro.setLayout(null);
		
		JButton btnVoltarToMainFramePanelRetLivro = new JButton("Voltar");
		btnVoltarToMainFramePanelRetLivro.setBackground(Color.RED);
		btnVoltarToMainFramePanelRetLivro.setFont(new Font("Tahoma", Font.PLAIN, 14));
		btnVoltarToMainFramePanelRetLivro.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frmDevoluoDeLivro.getContentPane().removeAll();
				frmDevoluoDeLivro.getContentPane().add(mainFrame);
				frmDevoluoDeLivro.getContentPane().repaint();
				frmDevoluoDeLivro.getContentPane().revalidate();
			}
		});
		
			//LISTA OS LIVROS QUE EST�O LOCADOS;
		
			JComboBox comboBox_RetirarLivro = new JComboBox();
			comboBox_RetirarLivro.setFont(new Font("Tahoma", Font.PLAIN, 14));
			comboBox_RetirarLivro.setBounds(124, 16, 186, 26);
			panelRetirarLivro.add(comboBox_RetirarLivro);
			
			File listaLivros = new File("dados/NomesLivrosCadastrados.txt");
			try {
			FileReader reader = new FileReader(listaLivros);
			BufferedReader buffer = new BufferedReader(reader);
			comboBox_RetirarLivro.addItem("--");
			for (int i = 0; i < listaLivros.length(); i++) {
				String nomeLivro = buffer.readLine();
				comboBox_RetirarLivro.addItem(nomeLivro);
			}
			
			buffer.close();
			reader.close();
			frmDevoluoDeLivro.getContentPane().removeAll();
			frmDevoluoDeLivro.getContentPane().add(mainFrame);
			frmDevoluoDeLivro.getContentPane().repaint();
			frmDevoluoDeLivro.getContentPane().revalidate();
			
			} catch (IOException e1) {
			e1.printStackTrace();
			
			}
			
			JComboBox comboBox_ChooseUser = new JComboBox();
			comboBox_ChooseUser.setFont(new Font("Tahoma", Font.PLAIN, 14));
			comboBox_ChooseUser.setBounds(124, 54, 186, 26);
			panelRetirarLivro.add(comboBox_ChooseUser);
			comboBox_ChooseUser.addItem("--");
			
			JButton btnRetirarLivro = new JButton("Retirar Livro");
			btnRetirarLivro.setFont(new Font("Tahoma", Font.PLAIN, 14));
			btnRetirarLivro.setBackground(Color.RED);
			btnRetirarLivro.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					
			//LISTA OS USUARIOS DISPONIVEIS NO SISTEMA;
					
					File listaUsers = new File("dados/NomesUsuarios.txt");
					try {
					FileReader reader = new FileReader(listaUsers);
					BufferedReader buffer = new BufferedReader(reader);
					
					for (int i = 0; i < listaUsers.length(); i++) {
						String nomeLivro = buffer.readLine();
						comboBox_ChooseUser.addItem(nomeLivro);
					}
					
					buffer.close();
					reader.close();
					frmDevoluoDeLivro.getContentPane().removeAll();
					frmDevoluoDeLivro.getContentPane().add(mainFrame);
					frmDevoluoDeLivro.getContentPane().repaint();
					frmDevoluoDeLivro.getContentPane().revalidate();
					
					} catch (IOException e1) {
					e1.printStackTrace();
					
					}
					
					frmDevoluoDeLivro.getContentPane().removeAll();
					frmDevoluoDeLivro.getContentPane().add(panelRetirarLivro);
					frmDevoluoDeLivro.getContentPane().repaint();
					frmDevoluoDeLivro.getContentPane().revalidate();
				
				}
			});
			btnRetirarLivro.setBounds(56, 130, 148, 53);
			mainFrame.add(btnRetirarLivro);
			
			JLabel lblNewLabel = new JLabel("Livro:");
			lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 14));
			lblNewLabel.setBounds(33, 21, 55, 16);
			panelRetirarLivro.add(lblNewLabel);
			
			JLabel lblNewLabel_1 = new JLabel("Usu\u00E1rio:");
			lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 14));
			lblNewLabel_1.setBounds(33, 59, 55, 16);
			panelRetirarLivro.add(lblNewLabel_1);
			
			textField_DataRetirada = new JTextField();
			textField_DataRetirada.setFont(new Font("Tahoma", Font.PLAIN, 14));
			textField_DataRetirada.setBounds(124, 92, 186, 28);
			panelRetirarLivro.add(textField_DataRetirada);
			textField_DataRetirada.setColumns(10);
			
			textField_DataDevolucao = new JTextField();
			textField_DataDevolucao.setFont(new Font("Tahoma", Font.PLAIN, 14));
			textField_DataDevolucao.setBounds(124, 132, 186, 26);
			panelRetirarLivro.add(textField_DataDevolucao);
			textField_DataDevolucao.setColumns(10);
			
			JLabel lblRetirada = new JLabel("Retirada:");
			lblRetirada.setFont(new Font("Tahoma", Font.PLAIN, 14));
			lblRetirada.setBounds(33, 98, 75, 16);
			panelRetirarLivro.add(lblRetirada);
			
			JLabel lblDevolucao = new JLabel("Devolu\u00E7\u00E3o:");
			lblDevolucao.setFont(new Font("Tahoma", Font.PLAIN, 14));
			lblDevolucao.setBounds(33, 137, 75, 16);
			panelRetirarLivro.add(lblDevolucao);
			
			btnVoltarToMainFramePanelRetLivro.setBounds(124, 211, 186, 28);
			panelRetirarLivro.add(btnVoltarToMainFramePanelRetLivro);
			
			JButton btnRetiroLivro_panelRetLivro = new JButton("Retirar Livro");
			btnRetiroLivro_panelRetLivro.setFont(new Font("Tahoma", Font.PLAIN, 14));
			btnRetiroLivro_panelRetLivro.setBackground(Color.RED);
			btnRetiroLivro_panelRetLivro.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					
					ArrayList<Emprestimo> emprestimos = new ArrayList<Emprestimo>();
					
					Emprestimo emp = new Emprestimo(comboBox_ChooseUser.getSelectedItem(),comboBox_RetirarLivro.getSelectedItem(),textField_DataRetirada.getText(),textField_DataDevolucao.getText());
					
					emprestimos.add(emp);
					
					try {
						
						EmprestimoLivros.createNewFile();
						FileWriter writer = new FileWriter(EmprestimoLivros,true);
						BufferedWriter buffer = new BufferedWriter(writer);
												
						for (Iterator iterator2 = emprestimos.iterator(); iterator2.hasNext();) {
							Emprestimo emprestimoLivros = (Emprestimo) iterator2.next();
							buffer.write("Nome do livro: "+emprestimoLivros.getNomeLivro()+"\n");
							buffer.write("Nome do Locat�rio: "+emprestimoLivros.getNomeUsuario()+"\n");
							buffer.write("Data de Loca��o: "+emprestimoLivros.getDataRetirada()+"\n");
							buffer.write("Data de Devolu��o: "+emprestimoLivros.getDataDevolucao()+"\n");
							buffer.write("------------------------------\n");
							
							}
						
						buffer.close();
						writer.close();
						textFieldFoneCadUser.setText("");
						textCPFCadUser.setText("");
						textFieldNameCadUser.setText("");
						frmDevoluoDeLivro.getContentPane().removeAll();
						frmDevoluoDeLivro.getContentPane().add(mainFrame);
						frmDevoluoDeLivro.getContentPane().repaint();
						frmDevoluoDeLivro.getContentPane().revalidate();
						
					} catch (IOException e1) {
						e1.printStackTrace();
					}
				}
			});
			
			btnRetiroLivro_panelRetLivro.setBounds(124, 173, 186, 28);
			panelRetirarLivro.add(btnRetiroLivro_panelRetLivro);
			
			
			
			
				
//###########################################################################################
// PARTE PARA TRATAR DO C�DIGO SOBRE CADASTRO DE USU�RIO:
		
		JPanel panelCadastrarUsuario = new JPanel();
		frmDevoluoDeLivro.getContentPane().add(panelCadastrarUsuario, "name_42072318718600");
		panelCadastrarUsuario.setLayout(null);
		
		JButton btnCadastrarUsuario = new JButton("Cadastrar Usuario");
		btnCadastrarUsuario.setFont(new Font("Tahoma", Font.PLAIN, 14));
		btnCadastrarUsuario.setBackground(Color.RED);
		btnCadastrarUsuario.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				frmDevoluoDeLivro.getContentPane().removeAll();
				frmDevoluoDeLivro.getContentPane().add(panelCadastrarUsuario);
				frmDevoluoDeLivro.getContentPane().repaint();
				frmDevoluoDeLivro.getContentPane().revalidate();
				
			}
		});
		
		JButton btnCdUserBackHome = new JButton("Voltar");
		btnCdUserBackHome.setBackground(Color.RED);
		btnCdUserBackHome.setFont(new Font("Tahoma", Font.PLAIN, 14));
		btnCdUserBackHome.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frmDevoluoDeLivro.getContentPane().removeAll();
				frmDevoluoDeLivro.getContentPane().add(mainFrame);
				frmDevoluoDeLivro.getContentPane().repaint();
				frmDevoluoDeLivro.getContentPane().revalidate();
			}
		});
		
		btnCdUserBackHome.setBounds(156, 212, 177, 28);
		panelCadastrarUsuario.add(btnCdUserBackHome);
		
		textFieldNameCadUser = new JTextField();
		textFieldNameCadUser.setFont(new Font("Tahoma", Font.PLAIN, 14));
		textFieldNameCadUser.setBounds(156, 22, 177, 28);
		panelCadastrarUsuario.add(textFieldNameCadUser);
		textFieldNameCadUser.setColumns(10);
		
		textFieldFoneCadUser = new JTextField();
		textFieldFoneCadUser.setFont(new Font("Tahoma", Font.PLAIN, 14));
		textFieldFoneCadUser.setColumns(10);
		textFieldFoneCadUser.setBounds(156, 125, 177, 28);
		panelCadastrarUsuario.add(textFieldFoneCadUser);
		
		JLabel lblNameUser = new JLabel("Nome:");
		lblNameUser.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblNameUser.setBounds(89, 27, 55, 16);
		panelCadastrarUsuario.add(lblNameUser);
		
		JLabel lblTelefone = new JLabel("Telefone:");
		lblTelefone.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblTelefone.setBounds(89, 130, 67, 16);
		panelCadastrarUsuario.add(lblTelefone);
		
		btnCadastrarUsuario.setBounds(56, 51, 148, 53);
		mainFrame.add(btnCadastrarUsuario);
		
		JLabel lblNewLabel_2 = new JLabel("CPF:");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblNewLabel_2.setBounds(89, 79, 55, 16);
		panelCadastrarUsuario.add(lblNewLabel_2);
		
		textCPFCadUser = new JTextField();
		textCPFCadUser.setFont(new Font("Tahoma", Font.PLAIN, 14));
		textCPFCadUser.setBounds(156, 73, 177, 28);
		panelCadastrarUsuario.add(textCPFCadUser);
		textCPFCadUser.setColumns(10);
		
		JButton btnCadastrarUser = new JButton("Cadastrar");
		btnCadastrarUser.setFont(new Font("Tahoma", Font.PLAIN, 14));
		btnCadastrarUser.setBackground(Color.RED);
		btnCadastrarUser.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				ArrayList<Usuario> usuarios = new ArrayList<Usuario>();
				
				Usuario user = new Usuario(textFieldNameCadUser.getText(),textCPFCadUser.getText(),textFieldFoneCadUser.getText());
				
				usuarios.add(user);
				
				//AQUI O PROGRAMA ESCREVE O USUARIO CADASTRADO DENTRO DO ARQUIVO;
				try {
					CadastroUsuarios.createNewFile();
					FileWriter writer = new FileWriter(CadastroUsuarios,true);
					BufferedWriter buffer = new BufferedWriter(writer);
					
					for (Iterator iterator2 = usuarios.iterator(); iterator2.hasNext();) {
						Usuario usuario = (Usuario) iterator2.next();
						buffer.write("Nome Completo: "+usuario.getNomeCompleto()+"\n");
						buffer.write("CPF: "+usuario.getCpf()+"\n");
						buffer.write("Telefone: "+usuario.getTelefone()+"\n");
						buffer.write("------------------------------\n");;
					}
					buffer.close();
					writer.close();
					textFieldFoneCadUser.setText("");
					textCPFCadUser.setText("");
					textFieldNameCadUser.setText("");
					
				} catch (IOException e1) {
					e1.printStackTrace();
				}
				
				//AQUI VAI SER ESCRITO SOMENTE O NOME NO ARQUIVO;
					
				try {
					NomesUsuarios.createNewFile();
					FileWriter writer = new FileWriter(NomesUsuarios,true);
					BufferedWriter buffer = new BufferedWriter(writer);
					
					for (Iterator iterator = usuarios.iterator(); iterator.hasNext();) {
						Usuario usuarios1 = (Usuario) iterator.next();
						buffer.write(usuarios1.getNomeCompleto()+"\n");
						
					}
					buffer.close();
					writer.close();
					
				} catch (IOException e1) {
					e1.printStackTrace();
				}
				
				File listaLivros = new File("dados/NomesUsuarios.txt");
				try {
				FileReader reader = new FileReader(listaLivros);
				BufferedReader buffer = new BufferedReader(reader);
				
				for (int i = 0; i < listaLivros.length(); i++) {
					String nomeLivro = buffer.readLine();
					comboBox_ChooseUser.addItem(nomeLivro);
				}
				
				buffer.close();
				reader.close();
				frmDevoluoDeLivro.getContentPane().removeAll();
				frmDevoluoDeLivro.getContentPane().add(mainFrame);
				frmDevoluoDeLivro.getContentPane().repaint();
				frmDevoluoDeLivro.getContentPane().revalidate();
				
				} catch (IOException e1) {
				e1.printStackTrace();
				
				}
				
			}
		});

		btnCadastrarUser.setBounds(156, 174, 177, 28);
		panelCadastrarUsuario.add(btnCadastrarUser);
		
		
		
		
		
		
		
		
//###########################################################################################
// PARTE DO CODIGO QUE TRATA SOBRE DEVOLU��O DE LIVRO;	
		
		JPanel panelDevolverLivro = new JPanel();
		frmDevoluoDeLivro.getContentPane().add(panelDevolverLivro, "name_42072327407900");
		panelDevolverLivro.setLayout(null);
		
		JComboBox Combobox_DevolverLivro = new JComboBox();
		Combobox_DevolverLivro.setFont(new Font("Tahoma", Font.PLAIN, 14));
		Combobox_DevolverLivro.setBounds(138, 76, 180, 26);
		panelDevolverLivro.add(Combobox_DevolverLivro);
		
		JLabel lblNewLabel_3 = new JLabel("Livro:");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblNewLabel_3.setBounds(84, 81, 44, 16);
		panelDevolverLivro.add(lblNewLabel_3);
		
		JButton btnGiveBack = new JButton("Devolver");
		btnGiveBack.setFont(new Font("Tahoma", Font.PLAIN, 14));
		btnGiveBack.setBackground(Color.RED);
		
		btnGiveBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				File listaEmprestimo = new File("dados/Emprestimos.txt");
				try {
				FileReader reader = new FileReader(listaEmprestimo);
				BufferedReader buffer = new BufferedReader(reader);
				Combobox_DevolverLivro.addItem("--");
				for (int i = 0; i < listaLivros.length(); i++) {
					String emp = buffer.readLine();
					Combobox_DevolverLivro.addItem(emp);
				}
				
				buffer.close();
				reader.close();
				frmDevoluoDeLivro.getContentPane().removeAll();
				frmDevoluoDeLivro.getContentPane().add(mainFrame);
				frmDevoluoDeLivro.getContentPane().repaint();
				frmDevoluoDeLivro.getContentPane().revalidate();
				
				} catch (IOException e1) {
				e1.printStackTrace();
				
				}
			}
		});
		btnGiveBack.setBounds(138, 129, 180, 28);
		panelDevolverLivro.add(btnGiveBack);
		
		JButton btnVoltarHomeDevolverLivro = new JButton("Voltar");
		btnVoltarHomeDevolverLivro.setBackground(Color.RED);
		btnVoltarHomeDevolverLivro.setFont(new Font("Tahoma", Font.PLAIN, 14));
		btnVoltarHomeDevolverLivro.setBounds(138, 167, 180, 28);
		panelDevolverLivro.add(btnVoltarHomeDevolverLivro);
		
		JButton btnDevolverLivro = new JButton("Devolver Livro");
		btnDevolverLivro.setFont(new Font("Tahoma", Font.PLAIN, 14));
		btnDevolverLivro.setBackground(Color.RED);
		btnDevolverLivro.setBounds(214, 130, 148, 53);
		mainFrame.add(btnDevolverLivro);
		
		
		
		
		
//###########################################################################################		
//AQUI � A PARTE EM QUE ESTAMOS TRABALHANDO NA PARTE DO CADASTRO DE LIVROS;
				
				JButton btnCadastrarLivro = new JButton("Cadastrar Livro"); //ENTRA NO MENU DE CADASTRAR LIVRO
				btnCadastrarLivro.setFont(new Font("Tahoma", Font.PLAIN, 14));
				btnCadastrarLivro.setBackground(Color.RED);
				btnCadastrarLivro.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						frmDevoluoDeLivro.getContentPane().removeAll();
						frmDevoluoDeLivro.getContentPane().add(panelCadastrarLivro);
						frmDevoluoDeLivro.getContentPane().repaint();
						frmDevoluoDeLivro.getContentPane().revalidate();
						
					}
				});
				btnCadastrarLivro.setBounds(214, 51, 148, 53);
				mainFrame.add(btnCadastrarLivro);
						
				panelCadastrarLivro = new JPanel();
				frmDevoluoDeLivro.getContentPane().add(panelCadastrarLivro, "name_42072314497100");
				panelCadastrarLivro.setLayout(null);
				
				JButton btnVoltarHome = new JButton("Voltar");
				btnVoltarHome.setFont(new Font("Tahoma", Font.PLAIN, 14));
				btnVoltarHome.setBackground(Color.RED);
				btnVoltarHome.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						frmDevoluoDeLivro.getContentPane().removeAll();
						frmDevoluoDeLivro.getContentPane().add(mainFrame);
						frmDevoluoDeLivro.getContentPane().repaint();
						frmDevoluoDeLivro.getContentPane().revalidate();
						
					}
				});
				
				btnVoltarHome.setBounds(166, 214, 193, 28);
				panelCadastrarLivro.add(btnVoltarHome);
				
				textFieldNomeLivro = new JTextField();
				textFieldNomeLivro.setFont(new Font("Tahoma", Font.PLAIN, 14));
				textFieldNomeLivro.setBounds(166, 23, 193, 28);
				panelCadastrarLivro.add(textFieldNomeLivro);
				textFieldNomeLivro.setColumns(10);
				
				textFieldAutor = new JTextField();
				textFieldAutor.setFont(new Font("Tahoma", Font.PLAIN, 14));
				textFieldAutor.setColumns(10);
				textFieldAutor.setBounds(166, 63, 193, 28);
				panelCadastrarLivro.add(textFieldAutor);
				
				JLabel lblNameCadUser = new JLabel("Nome:");
				lblNameCadUser.setFont(new Font("Tahoma", Font.PLAIN, 14));
				lblNameCadUser.setBounds(93, 28, 55, 16);
				panelCadastrarLivro.add(lblNameCadUser);
				
				JLabel lblAutor = new JLabel("Autor(a):");
				lblAutor.setFont(new Font("Tahoma", Font.PLAIN, 14));
				lblAutor.setBounds(93, 66, 68, 16);
				panelCadastrarLivro.add(lblAutor);
				
				TextField_Editoralivro = new JTextField();
				TextField_Editoralivro.setFont(new Font("Tahoma", Font.PLAIN, 14));
				TextField_Editoralivro.setBounds(166, 101, 193, 28);
				panelCadastrarLivro.add(TextField_Editoralivro);
				TextField_Editoralivro.setColumns(10);
				
				JLabel lblEditora = new JLabel("Editora:");
				lblEditora.setFont(new Font("Tahoma", Font.PLAIN, 14));
				lblEditora.setBounds(93, 104, 55, 16);
				panelCadastrarLivro.add(lblEditora);
				
				JComboBox comboBox = new JComboBox();
				comboBox.setFont(new Font("Tahoma", Font.PLAIN, 14));
				comboBox.setBounds(166, 139, 193, 26);
				panelCadastrarLivro.add(comboBox);
				comboBox.addItem(" -- ");
				comboBox.addItem("A��o");
				comboBox.addItem("Fic��o Cient�fica");
				comboBox.addItem("Romance");
				comboBox.addItem("Aventura");
				comboBox.addItem("Drama");
				
				JButton btnCadLivro = new JButton("Cadastrar");
				btnCadLivro.setBackground(Color.RED);
				btnCadLivro.setFont(new Font("Tahoma", Font.PLAIN, 14));
				btnCadLivro.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
				
					
					ArrayList<Livro> livros = new ArrayList<Livro>(); 
						
					Livro l = new Livro(textFieldNomeLivro.getText(), textFieldAutor.getText(), TextField_Editoralivro.getText(), comboBox.getSelectedItem());
					livros.add(l);
					
					
					//CADASTRO DO LIVRO
					try {
						CadastroLivros.createNewFile();
						FileWriter writer = new FileWriter(CadastroLivros,true);
						BufferedWriter buffer = new BufferedWriter(writer);
						
						for (Iterator iterator = livros.iterator(); iterator.hasNext();) {
							Livro livro = (Livro) iterator.next();
							buffer.write("Nome do Livro: "+livro.getNome()+"\n");
							buffer.write("Nome Autor: "+livro.getAutor()+"\n");
							buffer.write("G�nero: "+livro.getGenero()+"\n");
							buffer.write("Editora: "+livro.getEditora()+"\n");
							buffer.write("-----------------------------\n");
							
						}
						buffer.close();
						writer.close();
						textFieldAutor.setText("");
						textFieldNomeLivro.setText("");
						TextField_Editoralivro.setText("");

						
					} catch (IOException e1) {
						e1.printStackTrace();
					}
					
					//AQUI VAI SER ESCRITO SOMENTE O NOME NO ARQUIVO;
					
					try {
						NomesLivros.createNewFile();
						FileWriter writer = new FileWriter(NomesLivros,true);
						BufferedWriter buffer = new BufferedWriter(writer);
						
						for (Iterator iterator = livros.iterator(); iterator.hasNext();) {
							Livro livro = (Livro) iterator.next();
							buffer.write(livro.getNome()+"\n");
							
						}
			
						buffer.close();
						writer.close();
						
					} catch (IOException e1) {
						e1.printStackTrace();
					}
					
					File listaLivros = new File("dados/NomesLivrosCadastrados.txt");
					try {
					FileReader reader = new FileReader(listaLivros);
					BufferedReader buffer = new BufferedReader(reader);
					
					for (int i = 0; i < listaLivros.length(); i++) {
						String nomeLivro = buffer.readLine();
						comboBox_RetirarLivro.addItem(nomeLivro);
					}
					
					buffer.close();
					reader.close();
					frmDevoluoDeLivro.getContentPane().removeAll();
					frmDevoluoDeLivro.getContentPane().add(mainFrame);
					frmDevoluoDeLivro.getContentPane().repaint();
					frmDevoluoDeLivro.getContentPane().revalidate();
					
					} catch (IOException e1) {
					e1.printStackTrace();
					
					}
					
					}
					
				});
				btnCadLivro.setBounds(166, 176, 193, 28);
				panelCadastrarLivro.add(btnCadLivro);
				
				JLabel lblGenero = new JLabel("G\u00EAnero:");
				lblGenero.setFont(new Font("Tahoma", Font.PLAIN, 14));
				lblGenero.setBounds(93, 144, 55, 16);
				panelCadastrarLivro.add(lblGenero);

	}
}
